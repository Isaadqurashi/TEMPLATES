#include <iostream>

using namespace std;
 
const int TABLE_SIZE = 10;
 
class HashTable

{

private:

    int table[TABLE_SIZE];
 
public:

    HashTable()

    {

        for (int i = 0; i < TABLE_SIZE; i++)

        {

            table[i] = -1;

        }

    }
 
    int hash(int key)

    {

        return key % TABLE_SIZE;

    }
 
    void insert(int key)

    {

        int index = hash(key);
 
        while (table[index] != -1)

        {

            index = (index + 1) % TABLE_SIZE;

        }
 
        table[index] = key;

    }
 
    bool search(int key)

    {

        int index = hash(key);
 
        while (table[index] != -1)

        {

            if (table[index] == key)

            {

                return true;

            }

            index = (index + 1) % TABLE_SIZE;

        }
 
        return false;

    }
 
    void remove(int key)

    {

        int index = hash(key);
 
        while (table[index] != -1)

        {

            if (table[index] == key)

            {

                table[index] = -1;

                cout << "Key " << key << " removed from the hash table." << endl;

                return;

            }

            index = (index + 1) % TABLE_SIZE;

        }
 
        cout << "Key " << key << " not found in the hash table." << endl;

    }
 
    void display()

    {

        cout << "Hash Table: ";

        for (int i = 0; i < TABLE_SIZE; i++)

        {

            if (table[i] != -1)

            {

                cout << table[i] << " ";

            }

        }

        cout << endl;

    }

};
 
int main()

{

    HashTable hashTable;
 
    hashTable.insert(5);

    hashTable.insert(15);

    hashTable.insert(25);

    hashTable.insert(7);

    hashTable.insert(17);

    hashTable.insert(27);
 
    hashTable.display();
 
    cout << "Search 15: " << (hashTable.search(15) ? "Found" : "Not Found") << endl;

    cout << "Search 10: " << (hashTable.search(10) ? "Found" : "Not Found") << endl;
 
    hashTable.remove(15);

    hashTable.remove(10);
 
    hashTable.display();
 
    return 0;

}
 