/**
 *  author: saad khurshid
 *  created: 2024.12.06 17:25:29
 **/

#include <bits/stdc++.h>
#define fli(i,fc,n) for(int i=fc;i<n;i++)
#define rli(i,n,rc) for(int i=n;i>rc;i--)
#define sz(a) a.size()
#define ll long long
#define pb push_back
#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#define nl "\n"
using namespace std;

const int mv = 5;

class Graph {
private:
    int adjMatrix[mv][mv];
public:
    Graph() {
        fli(i, 0, mv) fli(j, 0, mv) adjMatrix[i][j] = 0;
    }

    void addEdge(int src, int dest, int wt) {
        adjMatrix[src][dest] = wt;
        adjMatrix[dest][src] = wt;
    }

    void printGraph() {
        fli(i, 0, mv) {
            cout << "Vertex " << i << " connections: ";
            fli(j, 0, mv) {
                if (adjMatrix[i][j] != 0) {
                    cout << j << "(" << adjMatrix[i][j] << ") ";
                }
            }
            cout << nl;
        }
    }

    void dfsTraversal(int startVertex) {
        bool visited[mv] = {0};
        stack<int> stk;
        stk.push(startVertex);
        while (!stk.empty()) {
            int curr = stk.top();
            stk.pop();
            if (!visited[curr]) {
                cout << curr << " ";
                visited[curr] = 1;
            }
            fli(i, 0, mv) {
                if (adjMatrix[curr][i] != 0 && !visited[i]) {
                    stk.push(i);
                }
            }
        }
        cout << nl;
    }
};

void saad() {
    Graph g;
    g.addEdge(0, 1, 1);
    g.addEdge(0, 2, 1);
    g.addEdge(0, 3, 1);
    g.addEdge(0, 4, 1);
    g.addEdge(1, 3, 1);
    g.addEdge(2, 4, 1);
    g.printGraph();
    cout << "DFS Traversal: ";
    g.dfsTraversal(0);
}

int main() {
    ios::sync_with_stdio(false), cin.tie(nullptr);
    int t = 1;
    while (t--) {
        saad();
    }
}
