#include <iostream>
using namespace std;

// Structure for an adjacency list node
struct AdjListNode {
    int data;
    AdjListNode* next;
};

// Structure for an adjacency list
struct AdjList {
    AdjListNode* head;
};

// Structure for a graph with an array of adjacency lists
struct Graph {
    int V; // Number of vertices
    AdjList* arr; // Array of adjacency lists
};

// Structure for stack using linked list
struct StackNode {
    int data;
    StackNode* next;
};

struct Stack {
    StackNode* top;

    Stack() { top = nullptr; }

    void push(int data) {
        StackNode* newNode = new StackNode;
        newNode->data = data;
        newNode->next = top;
        top = newNode;
    }

    int pop() {
        if (top == nullptr) return -1;
        int val = top->data;
        StackNode* temp = top;
        top = top->next;
        delete temp;
        return val;
    }

    bool isEmpty() { return top == nullptr; }
};

// Structure for queue using linked list
struct QueueNode {
    int data;
    QueueNode* next;
};

struct Queue {
    QueueNode* front;
    QueueNode* rear;

    Queue() { front = rear = nullptr; }

    void enqueue(int data) {
        QueueNode* newNode = new QueueNode;
        newNode->data = data;
        newNode->next = nullptr;
        if (rear == nullptr) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            rear = newNode;
        }
    }

    int dequeue() {
        if (front == nullptr) return -1;
        int val = front->data;
        QueueNode* temp = front;
        front = front->next;
        if (front == nullptr) rear = nullptr;
        delete temp;
        return val;
    }

    bool isEmpty() { return front == nullptr; }
};

// Function to create a new adjacency list node
AdjListNode* newAdjListNode(int data) {
    AdjListNode* nptr = new AdjListNode;
    nptr->data = data;
    nptr->next = nullptr;
    return nptr;
}

// Function to create a graph with V vertices
Graph* createGraph(int V) {
    Graph* graph = new Graph;
    graph->V = V;
    graph->arr = new AdjList[V];
    for (int i = 0; i < V; i++) {
        graph->arr[i].head = nullptr;
    }
    return graph;
}

// Function to add an edge to an undirected graph
void addEdge(Graph* graph, int src, int dest) {
    // Add an edge from src to dest
    AdjListNode* nptr = newAdjListNode(dest);
    nptr->next = graph->arr[src].head;
    graph->arr[src].head = nptr;

    // Add an edge from dest to src (since it's undirected)
    nptr = newAdjListNode(src);
    nptr->next = graph->arr[dest].head;
    graph->arr[dest].head = nptr;
}

// Function to perform BFS traversal
void BFS(Graph* graph, int start) {
    bool* visited = new bool[graph->V];
    for (int i = 0; i < graph->V; i++) visited[i] = false;

    Queue q;
    visited[start] = true;
    q.enqueue(start);

    while (!q.isEmpty()) {
        int v = q.dequeue();
        cout << v << " ";

        AdjListNode* temp = graph->arr[v].head;
        while (temp != nullptr) {
            int adj = temp->data;
            if (!visited[adj]) {
                visited[adj] = true;
                q.enqueue(adj);
            }
            temp = temp->next;
        }
    }
    delete[] visited;
    cout << endl;
}

// Function to perform DFS traversal
void DFS(Graph* graph, int start) {
    bool* visited = new bool[graph->V];
    for (int i = 0; i < graph->V; i++) visited[i] = false;

    Stack s;
    s.push(start);

    while (!s.isEmpty()) {
        int v = s.pop();

        if (!visited[v]) {
            visited[v] = true;
            cout << v << " ";
        }

        AdjListNode* temp = graph->arr[v].head;
        while (temp != nullptr) {
            int adj = temp->data;
            if (!visited[adj]) {
                s.push(adj);
            }
            temp = temp->next;
        }
    }
    delete[] visited;
    cout << endl;
}

// Function to print the graph (adjacency list representation)
void printGraph(Graph* graph) {
    if (!graph || !graph->arr) {
        cout << "Graph is empty or invalid." << endl;
        return;
    }
    for (int i = 0; i < graph->V; i++) {
        AdjListNode* root = graph->arr[i].head;
        cout << "Adjacency list of vertex " << i << ": ";
        while (root != nullptr) {
            cout << root->data << " -> ";
            root = root->next;
        }
        cout << "nullptr" << endl;
    }
}

// Main function to demonstrate the graph, BFS, and DFS
int main() {
    int totalVertices = 4;
    Graph* graph = createGraph(totalVertices);

    // Adding edges to the graph
    addEdge(graph, 0, 1);
    addEdge(graph, 0, 2);
    addEdge(graph, 1, 2);
    addEdge(graph, 2, 0);
    addEdge(graph, 0, 3);

    // Print the graph (Adjacency List Representation)
    cout << "Graph adjacency list representation:\n";
    printGraph(graph);

    // Perform BFS starting from vertex 2
    cout << "\nFollowing is Breadth First Traversal (starting from vertex 2):\n";
    BFS(graph, 2);

    // Perform DFS starting from vertex 2
    cout << "\nFollowing is Depth First Traversal (starting from vertex 2):\n";
    DFS(graph, 2);

    return 0;
}
