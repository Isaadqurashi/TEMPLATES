#include <iostream>
using namespace std;

void merge(int arr[],int left,int mid,int right){
    int n1= mid-left+1;
    int n2= right-mid;

    int l_arr[n1],r_arr[n2];
    for(int i=0;i<n1;i++){
        l_arr[i]=arr[left+i];
    }
    for(int j=0;j<n2;j++){
        r_arr[j]=arr[mid+j+1];
    }
    int i=0,j=0,k=left;
    while(i<n1 && j<n2){
        if(l_arr[i]<=r_arr[j]){
            arr[k]=l_arr[i];
            i++;         
        }else{
            arr[k]=r_arr[j];
            j++;     
        }
        k++;
    }
    while(i<n1){
        arr[k]=l_arr[i];
        i++;
        k++;
    }
    while(j<n2){
        arr[k]=r_arr[j];
        j++;
        k++;   
    }
}
void merge_sort(int left,int right,int arr[]){
    if(left<right){
        int mid=left+(right-left)/2;
        merge_sort(left,mid,arr);
        merge_sort(mid+1,right,arr);
        merge(arr,left,mid,right);
    }
}
int main(){
    int arr[4]={1456,123,678,789};
    int size =sizeof(arr)/sizeof(arr[0]);
    merge_sort(0,size-1,arr);
    for (int i = 0; i < size; i++) {
            cout << arr[i] << " ";
    }
}

