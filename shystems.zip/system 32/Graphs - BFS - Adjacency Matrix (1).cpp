#include <iostream>
#include <deque>
using namespace std;
#define MAX_VERTICES 5

class Graph
{
private:
    int adjacencyMatrix[MAX_VERTICES][MAX_VERTICES];

public:
    Graph() 
    {
        // Initialize the adjacency matrix with zeros
        for (int i = 0; i < MAX_VERTICES; i++)
        {
            for (int j = 0; j < MAX_VERTICES; j++)
            {
                adjacencyMatrix[i][j] = 0;
            }
        }
    }

    void addEdge(int source, int destination, int weight)
    {
        adjacencyMatrix[source][destination] = weight;
        adjacencyMatrix[destination][source] = weight;
    }
    
    void printGraph()
    {
        for (int i = 0; i < MAX_VERTICES; i++)
        {
            cout << "Vertex " << i << " connections: ";
            for (int j = 0; j < MAX_VERTICES; j++)
            {
                if (adjacencyMatrix[i][j] != 0)
                {
                    cout << j << "(" << adjacencyMatrix[i][j] << ") ";
                }
            }
            cout << endl;
        }
    }

    void printMatrix()
    {
        for (int i = 0; i < MAX_VERTICES; i++)
        {
            for (int j = 0; j < MAX_VERTICES; j++)
            {
                cout << adjacencyMatrix[i][j] << " ";
            }
            cout << endl;
        }
    }

    void bfsTraversal(int startVertex)
    {
        bool visited[MAX_VERTICES] = {false};
        deque<int> q;

        visited[startVertex] = true;
        q.push_back(startVertex);

        while (!q.empty())
        {
            int currentVertex = q.front();
            q.pop_front();

            cout << currentVertex << " ";

            for (int i = 0; i < MAX_VERTICES; i++)
            {
                if (adjacencyMatrix[currentVertex][i] != 0 && !visited[i])
                {
                    visited[i] = true;
                    q.push_back(i);
                }
            }
        }
        cout << endl;
    }
};

int main()
{
    Graph graph;

    // Add edges
    graph.addEdge(0, 1, 1);
    graph.addEdge(0, 2, 1);
    graph.addEdge(0, 3, 1);
    graph.addEdge(0, 4, 1);
    graph.addEdge(1, 3, 1);
    graph.addEdge(2, 4, 1);

    graph.printGraph();

    cout << "BFS Traversal: ";
    graph.bfsTraversal(0);
    
    return 0;
}
