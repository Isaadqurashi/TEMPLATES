#include <iostream>
#include <deque>
using namespace std;

#define MAX_VERTICES 5

class Graph
{
private:
    struct Node
    {
        int vertex;
        int weight;
        Node* next;
    };

    Node* adjacencyList[MAX_VERTICES];

public:
    Graph()
    {
        for (int i = 0; i < MAX_VERTICES; i++)
        {
            adjacencyList[i] = NULL;
        }
    }

    void addEdge(int source, int destination, int weight)
    {
        // Create a new node for the destination vertex
        Node* newNode = new Node;
        newNode->vertex = destination;
        newNode->weight = weight;
        newNode->next = NULL;

        // Insert the new node at the beginning of the adjacency list for the source vertex
        newNode->next = adjacencyList[source];
        adjacencyList[source] = newNode;
    }

    void printGraph()
    {
        for (int i = 0; i < MAX_VERTICES; i++)
        {
            cout << "Adjacency list for vertex " << i << ": ";
            Node* currentNode = adjacencyList[i];
            while (currentNode != NULL)
            {
                cout << "(" << currentNode->vertex << ", " << currentNode->weight << ") ";
                currentNode = currentNode->next;
            }
            cout << endl;
        }
    }

    void bfsTraversal(int startVertex)
    {
        bool visited[MAX_VERTICES] = {false};
        deque<int> q;

        visited[startVertex] = true;
        q.push_back(startVertex);

        while (!q.empty())
        {
            int currentVertex = q.front();
            q.pop_front();

            cout << currentVertex << " ";

            Node* currentNode = adjacencyList[currentVertex];
            while (currentNode != NULL)
            {
                int neighborVertex = currentNode->vertex;
                if (!visited[neighborVertex])
                {
                    visited[neighborVertex] = true;
                    q.push_back(neighborVertex);
                }
                currentNode = currentNode->next;
            }
        }
        cout << endl;
    }

};

int main()
{
    Graph graph;

    graph.addEdge(0, 1, 4);
    graph.addEdge(0, 2, 1);
    graph.addEdge(1, 3, 1);
    graph.addEdge(2, 1, 2);
    graph.addEdge(2, 3, 5);
    graph.addEdge(3, 4, 3);

    graph.printGraph();

    cout << "BFS Traversal: ";
    graph.bfsTraversal(0);

    return 0;
}
