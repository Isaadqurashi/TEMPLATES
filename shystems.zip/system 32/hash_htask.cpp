#include <iostream>
using namespace std;

const int TABLE_SIZE = 10;
const int MAX_CHAIN_LENGTH = 10;

class HashTable {
    int table[TABLE_SIZE][MAX_CHAIN_LENGTH];
    int chainSize[TABLE_SIZE];

public:
    HashTable() {
        for (int i = 0; i < TABLE_SIZE; i++) {
            chainSize[i] = 0;
            for (int j = 0; j < MAX_CHAIN_LENGTH; j++) table[i][j] = -1;
        }
    }
    int hash(int k) {return k % TABLE_SIZE;}
    
    void insert(int k) {
        int idx = hash(k);
        if (chainSize[idx] < MAX_CHAIN_LENGTH) table[idx][chainSize[idx]++] = k;
        else cout << "Chain overflow at index " << idx << endl;
    }

    bool search(int k) {
        int idx = hash(k);
        for (int i = 0; i < chainSize[idx]; i++) if (table[idx][i] == k) return true;
        return false;
    }

    void remove(int k) {
        int idx = hash(k);
        for (int i = 0; i < chainSize[idx]; i++) {
            if (table[idx][i] == k) {
                for (int j = i; j < chainSize[idx] - 1; j++) {
                    table[idx][j] = table[idx][j + 1];
                }
                chainSize[idx]--;
                cout << "Key " << k << " removed from the hash table." << endl;
                return;
            }
        }
        cout << "Key " << k << " not found in the hash table." << endl;
    }

    void display() {
        cout << "Hash Table:" << endl;
        for (int i = 0; i < TABLE_SIZE; i++) {
            cout << i << ": ";
            for (int j = 0; j < chainSize[i]; j++) cout << table[i][j] << " \n"[j == chainSize[i] - 1];
        }
    }
};

int main() {
    HashTable ht;
    ht.insert(5);
    ht.insert(15);
    ht.insert(25);
    ht.insert(7);
    ht.insert(17);
    ht.insert(27);

    ht.display();

    cout << "Search 15: " << (ht.search(15) ? "Found" : "Not Found") << endl;
    cout << "Search 10: " << (ht.search(10) ? "Found" : "Not Found") << endl;

    ht.remove(15);
    ht.remove(10);

    ht.display();
}
